#include <iostream>
#include <stdio.h>
#include <vector>
#include <algorithm>
#include <map>
#include <math.h>
#include <set>
#include <string>
#include <cmath>
#include <sstream>
#include <queue>

using namespace std;

#define TM 10000

int a[TM];
int main() {
	//freopen("C-small-attempt0.in.txt", "r", stdin);
	//freopen("output7.txt", "w", stdout);
	
	
	int t;
	scanf(" %d", &t);
	
	for(int cnt = 1; cnt <= t; cnt++) {
		
		int n, d;
		scanf(" %d %d", &d, &n);
		
		int cnt2 = 0;
		printf("Case #%d:\n", cnt);
		for(int i = 0; i < 50; i++) {
			string line = "";
			if(i % 2 == 0 && cnt2 < n) {
				for(int j = 0; j < 16 && cnt2 < n; j++) {
					line += "I/O";
					cnt2 += 1;
				}
				
				//cout << line.size() << endl;
				if(line.size() < 50) {
					for(int j = line.size(); j<50; j++) {
						line += "O";
					}
				}
			}  else {	
				for(int j = 0; j < 50; j++)
					line += "O";
			}
			cout << line << endl;	
		}
	}
	
	return 0;
}



